constexpr char const * AppName = "Object-Oriented (Basic)";
constexpr size_t AntCount = 200'000;
#include "ants-common.hpp"

#include <array>
#include <string>
#include <vector>

struct City {
    Vec2 pos;
    std::vector<int> neighbors;
};
struct Map {
    std::vector<City> cities;
};

class GO;
enum CompCat {
    CompCatProps,
    CompCatState,
    CompCatMover,
    CompCatBrain,
    CompCatRendr,
    
    CompCat_Count
};
static_assert(CompCatBrain > CompCatMover); // Brains must be updated after movers

struct IComponent {
    IComponent (GO * owner) : m_owner (owner) {}
    virtual ~IComponent () {}
    virtual GO const * owner () const {return m_owner;}
    virtual GO * owner () {return m_owner;}

    virtual void update (float time_delta) = 0;
private:
    GO * m_owner = nullptr;
};

class GO {
public:
    ~GO () {clear();}

    void clear () {
        for (auto & c : m_comps) {
            delete c;
            c = nullptr;
        }
    }

    template <typename CompT>
    IComponent * createComponent () {
        int cat = CompT::category;
        SDL_assert(cat < CompCat_Count);
        if (m_comps[cat] != nullptr) {
            delete m_comps[cat];
            m_comps[cat] = nullptr;
        }
        m_comps[cat] = new CompT (this);
        return m_comps[cat];
    }

    template <typename CompT>
    CompT const * get () const {
        SDL_assert(CompT::category < CompCat_Count);
        return dynamic_cast<CompT const *>(m_comps[CompT::category]);
    }
    template <typename CompT>
    CompT * get () {
        SDL_assert(CompT::category < CompCat_Count);
        return dynamic_cast<CompT *>(m_comps[CompT::category]);
    }

    auto const & all () const {return m_comps;}

    bool has_all () const {
        for (auto c : m_comps)
            if (nullptr == c)
                return false;
        return true;
    }

private:
    std::array<IComponent *, CompCat_Count> m_comps;
};

class Properties : public IComponent {
public:
    static constexpr CompCat category = CompCatProps;
    Properties (GO * owner) : IComponent (owner) {}
    
    virtual void update (float /*time_delta*/) override {}

    void init (std::string name, unsigned id, Color color, float speed, float wait_duration) {
        m_name = name;
        m_id = id;
        m_color = color;
        m_speed = speed;
        m_wait_duration = wait_duration;
    }

    std::string const & name () const {return m_name;}
    unsigned const & id () const {return m_id;}
    Color const & color () const {return m_color;}
    float const & speed () const {return m_speed;}
    float const & wait_duration () const {return m_wait_duration;}

private:
    std::string m_name;
    unsigned m_id;
    Color m_color;
    float m_speed;
    float m_wait_duration;
};

class State : public IComponent {
public:
    static constexpr CompCat category = CompCatState;
    State (GO * owner) : IComponent (owner) {}
    
    virtual void update (float /*time_delta*/) override {}

    bool & moving () {return m_moving;}

private:
    bool m_moving = false;
};

class LinearMover : public IComponent {
public:
    static constexpr CompCat category = CompCatMover;
    LinearMover (GO * owner) : IComponent (owner) {}

    virtual void update (float time_delta) override {
        auto props = owner()->get<Properties>();
        auto state = owner()->get<State>();
        if (state->moving()) {
            m_dist += props->speed() * time_delta;
            auto dist_to_go = Length(m_to - m_from);
            if (m_dist > dist_to_go)
                m_dist = dist_to_go;
        }
    }

    void init (Vec2 const & from, Vec2 const & to) {
        reset(from, to);
    }

    void reset (Vec2 const & from, Vec2 const & to) {
        m_from = from;
        m_to = to;

        m_dist = 0;
    }
    Vec2 pos () const {
        auto dir = Normalized(m_to - m_from);
        return m_from + m_dist * dir;
    }
    bool arrived () const {
        auto dist_to_go = Length(m_to - m_from);
        return m_dist >= dist_to_go;
    }

private:
    Vec2 m_from;
    Vec2 m_to;

    float m_dist;
};

class PixelRenderer : public IComponent {
public:
    static constexpr CompCat category = CompCatRendr;
    PixelRenderer (GO * owner) : IComponent (owner) {}
    
    virtual void update (float /*time_delta*/) override {}

    void render (Canvas * canvas) const {
        auto props = owner()->get<Properties>();
        auto mover = owner()->get<LinearMover>();

        PutPixel(canvas, int(mover->pos().x), int(mover->pos().y), props->color());
        //PutPixel(canvas, int(mover->pos().x) + 1, int(mover->pos().y), props->color());
        //PutPixel(canvas, int(mover->pos().x) - 1, int(mover->pos().y), props->color());
        //PutPixel(canvas, int(mover->pos().x), int(mover->pos().y) + 1, props->color());
        //PutPixel(canvas, int(mover->pos().x), int(mover->pos().y) - 1, props->color());
        //PutPixel(canvas, int(mover->pos().x) + 1, int(mover->pos().y) + 1, props->color());
        //PutPixel(canvas, int(mover->pos().x) - 1, int(mover->pos().y) + 1, props->color());
        //PutPixel(canvas, int(mover->pos().x) + 1, int(mover->pos().y) - 1, props->color());
        //PutPixel(canvas, int(mover->pos().x) - 1, int(mover->pos().y) - 1, props->color());
    }

private:
};

class IBrain : public IComponent {
public:
    static constexpr CompCat category = CompCatBrain;
    IBrain (GO * owner) : IComponent (owner) {}

    virtual void init (Map const * map, unsigned city_1, unsigned city_2) {
        m_map = map;
        m_city_from = city_1;
        m_city_to = city_2;
        m_waited = owner()->get<Properties>()->wait_duration();
        owner()->get<State>()->moving() = false;
    }

protected:
    Map const * m_map;
    unsigned m_city_from;
    unsigned m_city_to;
    float m_waited;
};

class RandomWalkBrain : public IBrain {
public:
    static constexpr CompCat category = CompCatBrain;
    RandomWalkBrain (GO * owner) : IBrain (owner) {}

    virtual void update (float time_delta) override {
        auto state = owner()->get<State>();
        if (state->moving()) {
            auto mover = owner()->get<LinearMover>();
            if (mover->arrived()) {
                state->moving() = false;
                m_waited = 0;
            }
        } else {
            auto props = owner()->get<Properties>();
            if (m_waited >= props->wait_duration()) {
                m_city_from = m_city_to;
                auto next_neighbor = RandIntSmall(0, int(m_map->cities[m_city_from].neighbors.size()));
                m_city_to = m_map->cities[m_city_from].neighbors[next_neighbor];

                auto mover = owner()->get<LinearMover>();
                mover->reset(m_map->cities[m_city_from].pos, m_map->cities[m_city_to].pos);

                state->moving() = true;
            } else {
                m_waited += time_delta;
            }
        }
    }
};

class RoundtripBrain : public IBrain{
public:
    static constexpr CompCat category = CompCatBrain;
    RoundtripBrain (GO * owner) : IBrain (owner) {}

    virtual void update (float time_delta) override {
        auto state = owner()->get<State>();
        if (state->moving()) {
            auto mover = owner()->get<LinearMover>();
            if (mover->arrived()) {
                state->moving() = false;
                m_waited = 0;
            }
        } else {
            auto props = owner()->get<Properties>();
            if (m_waited >= props->wait_duration()) {
                std::swap(m_city_from, m_city_to);

                auto mover = owner()->get<LinearMover>();
                mover->reset(m_map->cities[m_city_from].pos, m_map->cities[m_city_to].pos);

                state->moving() = true;
            } else {
                m_waited += time_delta;
            }
        }
    }
};

struct Colony {
    std::vector<GO> ants;
};

Map g_map;
Colony g_colony;

static void
Init (int width, int height) {
    auto n = CityCount; //unsigned(RandIntSmall(2, CityCount));
    g_map.cities.resize(n);
    for (unsigned i = 0; i < n; ++i) {
        g_map.cities[i].pos = RandPoint(width - 2, height - 2) + Vec2{1, 1};
        for (unsigned j = 0; j < i; ++j) {
            if (RandUniform() <= CityNeigborhoodProb) {
                g_map.cities[i].neighbors.push_back(j);
                g_map.cities[j].neighbors.push_back(i);
            }
        }
    }

    auto m = AntCount;
    g_colony.ants.resize(m);
    for (unsigned i = 0; i < m; ++i) {
        unsigned city = RandIntSmall(0, int(g_map.cities.size()));
        unsigned neighbor = g_map.cities[city].neighbors[RandIntSmall(0, int(g_map.cities[city].neighbors.size()))];
        float speed = RandRange(SpeedMin, SpeedMax);
        float wait = RandRange(WaitMin, WaitMax);
        Color color = {
            uint8_t(RandIntSmall(128, 256)),
            uint8_t(RandIntSmall(128, 256)),
            uint8_t(RandIntSmall(128, 256))
        };

        auto & ant = g_colony.ants[i];

        ant.createComponent<Properties>();
        ant.createComponent<State>();
        ant.createComponent<LinearMover>();
        if (RandUniform() <= 0.5f)
            ant.createComponent<RandomWalkBrain>();
        else
            ant.createComponent<RoundtripBrain>();
        ant.createComponent<PixelRenderer>();
        SDL_assert(ant.has_all());

        ant.get<Properties>()->init("", i, color, speed, wait);
        ant.get<LinearMover>()->init(RandPoint(width, height), RandPoint(width - 2, height - 2) + Vec2{1, 1});   // Only needed for the case where we render without updating.
        ant.get<IBrain>()->init(&g_map, neighbor, city);
    }
}

static void
Deinit () {
    g_colony.ants.clear();
    g_map.cities.clear();
}

static void
Update (unsigned /*frame_number*/) {
    for (auto & a : g_colony.ants)
        for (auto & c : a.all())
            c->update(1.0f);
}

static void
Render (unsigned /*frame_number*/, Canvas * canvas) {
    for (auto const & a : g_colony.ants) {
        auto p = a.get<PixelRenderer>();
        if (p)
            p->render(canvas);
    }
}
