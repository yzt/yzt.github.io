#pragma once

#pragma comment (lib, "Imm32")
#pragma comment (lib, "Version")
#pragma comment (lib, "WinMM")
#if !defined(_DEBUG)
#pragma comment (lib, "../SDL2-static.lib")
#pragma comment (lib, "../SDL2main.lib")
#else   // !defined(_DEBUG)
#pragma comment (lib, "../SDL2-staticd.lib")
#pragma comment (lib, "../SDL2maind.lib")
#endif  // !defined(_DEBUG)

#pragma warning (disable: 4127) // conditional expression is constant
#pragma warning (disable: 4505) // unreferenced local function has been removed

#include "SDL2/SDL.h"
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>  // rand()
#include <cstring>  // memcpy()

//constexpr int TestSeconds = 5;

struct Vec2 {
    float x, y;
};

static inline Vec2 operator - (Vec2 const & v, Vec2 const & u) {return {v.x - u.x, v.y - u.y};}
static inline Vec2 operator + (Vec2 const & v, Vec2 const & u) {return {v.x + u.x, v.y + u.y};}
static inline Vec2 operator * (float v, Vec2 const & u) {return {v * u.x, v * u.y};}
static inline Vec2 operator * (Vec2 const & v, float u) {return {v.x * u, v.y * u};}
static inline Vec2 & operator += (Vec2 & v, Vec2 const & u) {v.x += u.x; v.y += u.y; return v;}

struct Color {
    uint8_t b, g, r, a;

    Color () : b (0), g (0), r (0), a (0) {}
    Color (uint8_t r_, uint8_t g_, uint8_t b_, uint8_t a_ = 255) : b (b_), g (g_), r (r_), a (a_) {}
};

struct Canvas {
    Color * pixels;
    int width, height;
    int pitch_bytes;
    
    SDL_Texture * texture;
    SDL_Renderer * renderer;

    Color * row (int r) {
        return (Color *)((char *)pixels + intptr_t(pitch_bytes * r));
    }
};

static inline void
Texture_ClearToBlack (Canvas * canvas) {
    auto size = size_t(canvas->height) * canvas->pitch_bytes;
    ::memset(canvas->pixels, 0, size);
}

static inline void
PutPixel (Canvas * canvas, int x, int y, Color c) {
    Color * p = canvas->row(y) + x;
    *p = c;
}

static inline float
RandUniform () {    // in [0..1]
    return float(rand()) / RAND_MAX;
}

static inline float
RandRange (float low_inc, float high_inc) {
    return (high_inc - low_inc) * RandUniform() + low_inc;
}

static inline int
RandIntSmall (int low_inc, int high_exc) {
    return rand() % (high_exc - low_inc) + low_inc;
}

static inline Vec2
RandPoint (int width, int height) {
    return {RandRange(0, float(width - 1)), RandRange(0, float(height - 1))};
}

static inline float
Length (Vec2 const & v) {
    return ::sqrt(v.x * v.x + v.y * v.y);
}

static inline Vec2
Normalized (Vec2 const & v) {
    float inv_len = 1.0f / Length(v);
    return {v.x * inv_len, v.y * inv_len};
}


static char const *
NumToStr (unsigned long long x) {
    static char buff [100];
    int cur = 0, digs = 0;

    do {
        if (digs > 0 && (digs % 3 == 0))
            buff[cur++] = '\'';
        buff[cur++] = '0' + (x % 10);
        x /= 10;
        digs += 1;
    } while (x > 0);
    buff[cur] = '\0';

    for (int i = 0, j = cur - 1; i < j; ++i, --j) {
        auto t = buff[i];
        buff[i] = buff[j];
        buff[j] = t;
    }

    return buff;
}

static void Init (int width, int height);
static void Update (unsigned frame_number);
static void Render (unsigned frame_number, Canvas * canvas);
static void Deinit (/*unsigned total_frames, double total_seconds*/);

static bool g_should_really_exit = false;

template <bool DoUpdate, bool DoRender>
static double
MainLoop (Canvas * canvas, double per_frame_overhead) {
    uint64_t time_freq = SDL_GetPerformanceFrequency();

    auto init_t0 = SDL_GetPerformanceCounter();
    Init(canvas->width, canvas->height);
    auto init_dt = SDL_GetPerformanceCounter() - init_t0;

    uint64_t time_start = SDL_GetPerformanceCounter();
    //uint64_t time_target = time_start + TestSeconds * time_freq;
    unsigned frame_number = 0;
    for (;;) {
    #if 0
        if (true || (frame_number % 32) == 0) {
            uint64_t time_current = SDL_GetPerformanceCounter();
            if (time_current >= time_target)
                break;
        }
    #else
        bool should_exit = false;
        SDL_Event ev = {};
        while (SDL_PollEvent(&ev)) {
            if (ev.type == SDL_QUIT)
                g_should_really_exit = true;
            if (ev.type == SDL_QUIT || ev.type == SDL_KEYUP)
                should_exit = true;
        }
        if (should_exit)
            break;
    #endif
        frame_number += 1;

        // Update...
        if constexpr (DoUpdate) {
            Update(frame_number);
        }

        // Render...
        SDL_LockTexture(canvas->texture, nullptr, reinterpret_cast<void **>(&canvas->pixels), &canvas->pitch_bytes);
        SDL_assert(canvas->pixels && canvas->pitch_bytes > 0);
        Texture_ClearToBlack(canvas);

        if constexpr (DoRender) {
            Render(frame_number, canvas);
        }

        SDL_UnlockTexture(canvas->texture);
        SDL_RenderCopy(canvas->renderer, canvas->texture, nullptr, nullptr);

        // Swap...
        SDL_RenderPresent(canvas->renderer);
    }
    uint64_t time_finish = SDL_GetPerformanceCounter();

    double duration_secs = double(time_finish - time_start) / time_freq;

    auto deinit_t0 = SDL_GetPerformanceCounter();
    Deinit(/*frame_number, duration_secs*/);
    auto deinit_dt = SDL_GetPerformanceCounter() - deinit_t0;

    double per_frame_s = duration_secs / frame_number;
    double per_ant_ns = per_frame_s * (1'000'000'000.0 / AntCount);
    double per_ant_ns_sans_overhead = (per_frame_s - per_frame_overhead) * (1'000'000'000.0 / AntCount);

    ::printf("                      Total Time: %14.3f s  (init: %0.2f ms, deinit: %0.2f ms)\n", duration_secs, 1000.0 * init_dt / time_freq, 1000.0 * deinit_dt / time_freq);
    ::printf("                    Total Frames: %10u\n", frame_number);
    ::printf("                      Frame Time: %14.3f ms\n", duration_secs / frame_number * 1000);
    ::printf("               Frames per Second: %12.1f\n", frame_number / duration_secs);
    ::printf("  Average time per ant per frame: %14.3f ns   <----\n", per_ant_ns);
    if (per_frame_overhead > 0)
        ::printf("   ... per ant, without overhead: %14.3f ns\n", per_ant_ns_sans_overhead);
    ::printf("\n");

    return per_frame_s;
}

extern "C" int
SDL_main (int /*argc*/, char * /*argv*/ []) {
    SDL_Init(SDL_INIT_VIDEO);

    SDL_Window * window = nullptr;
    SDL_Renderer * renderer = nullptr;
    SDL_CreateWindowAndRenderer(800, 800, 0, &window, &renderer);

    char window_title [200];
    snprintf(window_title, sizeof(window_title), "%s (Press any key to advance to next phase.)", AppName);
    SDL_SetWindowTitle(window, window_title);

    int width = 0, height = 0;
    SDL_GetWindowSize(window, &width, &height);
    auto texture = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_ARGB8888, SDL_TEXTUREACCESS_STREAMING, width, height);

    Canvas canvas = {};
    canvas.width = width;
    canvas.height = height;
    canvas.texture = texture;
    canvas.renderer = renderer;

    #if defined(_DEBUG)
        #define BUILD   "Debug"
    #else
        #define BUILD   "Release"
    #endif
    ::printf("    Application: %s\n", AppName);
    ::printf("     Build type: %zu-bit, %s\n", 8 * sizeof(void *), BUILD);
    ::printf(" Number of Ants: %s\n", NumToStr(AntCount));
    ::printf("\n");

    ::printf("[Just Overhead]\n");
    auto per_frame_overhead = MainLoop<false, false>(&canvas, 0);
    if (g_should_really_exit) ::exit(0);

    ::printf("[Only Update]\n");
    MainLoop<true, false>(&canvas, per_frame_overhead);
    if (g_should_really_exit) ::exit(0);

    ::printf("[Only Render]\n");
    MainLoop<false, true>(&canvas, per_frame_overhead);
    if (g_should_really_exit) ::exit(0);

    ::printf("[With Update and Render]\n");
    MainLoop<true, true>(&canvas, per_frame_overhead);
    if (g_should_really_exit) ::exit(0);

    SDL_DestroyTexture(texture);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
    return 0;
}

constexpr size_t CityCount = 200;
constexpr float CityNeigborhoodProb = 0.5f;
constexpr float SpeedMin = 0.1f;
constexpr float SpeedMax = 1.5f;
constexpr float WaitMin = 3.0f;
constexpr float WaitMax = 50.0f;
