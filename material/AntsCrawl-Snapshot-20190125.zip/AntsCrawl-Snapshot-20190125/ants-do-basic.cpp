constexpr char const * AppName = "Data-Oriented (Basic)";
constexpr size_t AntCount = 2'000'000;
#include "ants-common.hpp"

#include <array>
#include <string>
#include <vector>

struct City {
    Vec2 pos;
    std::vector<int> neighbors;
};
struct Map {
    std::vector<City> cities;
};

struct Colony {
    size_t randomwalkers_begin;
    size_t randomwalkers_end;
    size_t roundtrippers_begin;
    size_t roundtrippers_end;

    std::vector<Color> color;
    std::vector<float> speed;
    std::vector<float> wait;

    std::vector<int> from;
    std::vector<int> to;

    std::vector<Vec2> pos;
    std::vector<Vec2> step;
    std::vector<int> steps_to_go;

    std::vector<int> steps_to_wait;
};

Map g_map;
Colony g_colony;

static void
Init (int width, int height) {
    auto n = CityCount; //unsigned(RandIntSmall(2, CityCount));
    g_map.cities.resize(n);
    for (unsigned i = 0; i < n; ++i) {
        g_map.cities[i].pos = RandPoint(width - 2, height - 2) + Vec2{1, 1};
        for (unsigned j = 0; j < i; ++j) {
            if (RandUniform() <= CityNeigborhoodProb) {
                g_map.cities[i].neighbors.push_back(j);
                g_map.cities[j].neighbors.push_back(i);
            }
        }
    }

    auto m = AntCount;
    g_colony.color.resize(m);
    g_colony.speed.resize(m);
    g_colony.wait.resize(m);
    g_colony.from.resize(m);
    g_colony.to.resize(m);
    g_colony.pos.resize(m);
    g_colony.step.resize(m);
    g_colony.steps_to_go.resize(m);
    g_colony.steps_to_wait.resize(m);

    g_colony.randomwalkers_begin = 0;
    g_colony.randomwalkers_end = m / 2;
    g_colony.roundtrippers_begin = g_colony.randomwalkers_end;
    g_colony.roundtrippers_end = m;

    for (unsigned i = 0; i < m; ++i) {
        unsigned city = RandIntSmall(0, int(g_map.cities.size()));
        unsigned neighbor = g_map.cities[city].neighbors[RandIntSmall(0, int(g_map.cities[city].neighbors.size()))];
        float speed = RandRange(SpeedMin, SpeedMax);
        float wait = RandRange(WaitMin, WaitMax);
        Color color = {
            uint8_t(RandIntSmall(128, 256)),
            uint8_t(RandIntSmall(128, 256)),
            uint8_t(RandIntSmall(128, 256))
        };

        //...
        g_colony.color[i] = color;
        g_colony.speed[i] = speed;
        g_colony.wait[i] = wait;

        g_colony.from[i] = city;
        g_colony.to[i] = neighbor;

        auto p0 = g_map.cities[city].pos;
        auto p1 = g_map.cities[neighbor].pos;
        g_colony.pos[i] = p0;
        g_colony.step[i] = Normalized(p1 - p0) * speed;
        g_colony.steps_to_go[i] = int(::ceil(Length(p1 - p0) / speed));
    }
}

static void
Deinit () {
    g_colony.steps_to_wait.clear();
    g_colony.steps_to_go.clear();
    g_colony.step.clear();
    g_colony.pos.clear();
    g_colony.to.clear();
    g_colony.from.clear();
    g_colony.wait.clear();
    g_colony.speed.clear();
    g_colony.color.clear();

    g_map.cities.clear();
}

static void
Update (unsigned /*frame_number*/) {
    auto begin = g_colony.randomwalkers_begin;
    auto end = g_colony.randomwalkers_end;
    for (size_t i = begin; i < end; ++i) {
        if (g_colony.steps_to_go[i] > 0) {
            g_colony.pos[i] += g_colony.step[i];
            g_colony.steps_to_go[i] -= 1;
            if (g_colony.steps_to_go[i] == 0) {
                g_colony.steps_to_wait[i] = unsigned(::ceil(g_colony.wait[i]));
            }
        } else if (g_colony.steps_to_wait[i] > 0) {
            g_colony.steps_to_wait[i] -= 1;
        } else {
            unsigned city = g_colony.to[i];
            unsigned neighbor = g_map.cities[city].neighbors[RandIntSmall(0, int(g_map.cities[city].neighbors.size()))];

            auto p0 = g_map.cities[city].pos;
            auto p1 = g_map.cities[neighbor].pos;
            g_colony.from[i] = city;
            g_colony.to[i] = neighbor;
            g_colony.pos[i] = p0;
            g_colony.step[i] = Normalized(p1 - p0) * g_colony.speed[i];
            g_colony.steps_to_go[i] = int(::ceil(Length(p1 - p0) / g_colony.speed[i]));
        }
    }

    begin = g_colony.roundtrippers_begin;
    end = g_colony.roundtrippers_end;
    for (size_t i = begin; i < end; ++i) {
        if (g_colony.steps_to_go[i] > 0) {
            g_colony.pos[i] += g_colony.step[i];
            g_colony.steps_to_go[i] -= 1;
            if (g_colony.steps_to_go[i] == 0) {
                g_colony.steps_to_wait[i] = unsigned(::ceil(g_colony.wait[i]));
            }
        } else if (g_colony.steps_to_wait[i] > 0) {
            g_colony.steps_to_wait[i] -= 1;
        } else {
            unsigned city = g_colony.to[i];
            unsigned neighbor = g_colony.from[i];

            auto p0 = g_map.cities[city].pos;
            auto p1 = g_map.cities[neighbor].pos;
            g_colony.from[i] = city;
            g_colony.to[i] = neighbor;
            g_colony.pos[i] = p0;
            g_colony.step[i] = Normalized(p1 - p0) * g_colony.speed[i];
            g_colony.steps_to_go[i] = int(::ceil(Length(p1 - p0) / g_colony.speed[i]));
        }
    }
}

static void
Render (unsigned /*frame_number*/, Canvas * canvas) {
    auto n = int(g_colony.color.size());
    for (int i = 0; i < n; ++i) {
        PutPixel(canvas, int(g_colony.pos[i].x), int(g_colony.pos[i].y), g_colony.color[i]);
    }
}
