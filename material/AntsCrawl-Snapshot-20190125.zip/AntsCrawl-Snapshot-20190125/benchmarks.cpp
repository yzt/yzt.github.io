#include <cstdint>
#include <cstdio>
#include <chrono>

extern "C" int ASMRand (void);
extern "C" volatile void ASMLoop (void);

static inline double
Now () {
    using namespace std::chrono;
    return duration_cast<duration<double>>(steady_clock::now().time_since_epoch()).count();
}

static char const *
BytesStr (size_t v) {
    static char buffer [200];
    if (v >= 1024 * 1024 * 1024) {
        ::snprintf(buffer, sizeof(buffer), "%.0f GiB", v / double(1024 * 1024 * 1024));
    } else if (v >= 1024 * 1024) {
        ::snprintf(buffer, sizeof(buffer), "%.0f MiB", v / double(1024 * 1024));
    } else if (v >= 1024) {
        ::snprintf(buffer, sizeof(buffer), "%.0f KiB", v / double(1024));
    } else {
        ::snprintf(buffer, sizeof(buffer), "%zu B", v);
    }
    return buffer;
}

int main () {
    constexpr size_t MemBytes = 512 * 1024 * 1024;
    constexpr size_t LoopCount = 3;
    constexpr size_t TestCount = 3; 
    constexpr uint64_t Prime = 10'000'000'002'065'383ULL; // 99999999999899999; // 1'000'000'000'000'000'003; //
    constexpr size_t BufferSize = MemBytes / sizeof(size_t);
    auto mem = new size_t [BufferSize];
    auto idx = new size_t [BufferSize];
    for (size_t i = 0; i < BufferSize; ++i)
        mem[i] = i;
    size_t total = 0;

    double per_iteration_empty_loop_overhead_s = 0;
    ::printf("[Loop Overhead Tests]\n");
    {
        uint64_t LoopCount = 4ULL * 1024 * 1024 * 1024;
        double fastest = 999'999'999.0, sum_t = 0;
        for (size_t t = 0; t < TestCount; ++t) {
            auto t0 = Now();
            ASMLoop();  // contains 10 * 1024 * 1024 * 1024 iterations
            auto dt = Now() - t0;
            sum_t += dt;
            if (fastest > dt)
                fastest = dt;
        }
        double per_iteration = fastest * (1'000'000'000.0 / LoopCount);
        double average_per_iter = sum_t / TestCount * (1'000'000'000.0 / LoopCount);
        ::printf(" Total: %0.3f ms, per-iteration: %0.3f ns, average: %0.3f ns\n", 1000 * fastest, per_iteration, average_per_iter);
        per_iteration_empty_loop_overhead_s = fastest / LoopCount;
    }

    double min_ns = 10000000, max_ns = -1;
    ::printf("\n[Sequential Tests]\n");
    for (size_t cur_bytes = 8192; cur_bytes <= MemBytes; cur_bytes *= 2) {
        size_t cur_size = cur_bytes / sizeof(size_t);
        for (size_t i = 0; i < cur_size; ++i) {
            idx[i] = i;
        }
        size_t cur_loop_cnt = LoopCount * MemBytes / cur_bytes;
        double fastest = 999'999'999.0;
        for (size_t t = 0; t < TestCount; ++t) {
            auto t0 = Now();
            for (size_t l = 0; l < cur_loop_cnt; ++l) {
                size_t sum = 0;
                for (size_t i = 0; i < cur_size; ++i) {
                    sum += mem[idx[i]];
                }
                total += sum;
            }
            auto dt = Now() - t0;
            if (fastest > dt)
                fastest = dt;
        }

        double loop_overhead = double(cur_loop_cnt) * cur_size * per_iteration_empty_loop_overhead_s;
        double fastest_nov = fastest - loop_overhead;
        uint64_t bytes_touched = 2 * cur_loop_cnt * cur_bytes;
        uint64_t lines_touched = bytes_touched / 64;
        double bandwidth_gbps = bytes_touched / fastest / (1024 * 1024 * 1024);
        double latency_ns = fastest / lines_touched * 1'000'000'000;
        double bandwidth_gbps_nov = bytes_touched / fastest_nov / (1024 * 1024 * 1024);
        double latency_ns_nov = fastest_nov / lines_touched * 1'000'000'000;
        ::printf(" %7s : %0.3f s, %6.3f GiB/s, %6.3f ns    (%0.3f s, %7.3f GiB/s, %6.3f ns)\n"
            , BytesStr(2 * cur_bytes)
            , fastest, bandwidth_gbps, latency_ns
            , fastest_nov, bandwidth_gbps_nov, latency_ns_nov
        );

        if (latency_ns_nov < min_ns) min_ns = latency_ns_nov;
        if (latency_ns_nov > max_ns) max_ns = latency_ns_nov;
    }
    ::printf ("\nSlowest to fastest latency ratio: %0.1f\n", max_ns / min_ns);

    min_ns = 10000000, max_ns = -1;
    ::printf("\n[Random-Access Tests]\n");
    for (size_t cur_bytes = 8192; cur_bytes <= MemBytes; cur_bytes *= 2) {
        size_t cur_size = cur_bytes / sizeof(size_t);
        for (size_t i = 0; i < cur_size; ++i) {
            idx[i] = (i * Prime) % cur_size;
        }
        size_t cur_loop_cnt = LoopCount * MemBytes / cur_bytes;
        size_t mask = cur_size - 1; // Hopefully, cur_size is a power of two!
        double fastest = 999'999'999.0;
        for (size_t t = 0; t < TestCount; ++t) {
            auto t0 = Now();
            for (size_t l = 0; l < cur_loop_cnt; ++l) {
                size_t sum = 0;
                for (size_t i = 0; i < cur_size; ++i) {
                    sum += mem[idx[i]];
                }
                total += sum;
            }
            auto dt = Now() - t0;
            if (fastest > dt)
                fastest = dt;
        }

        double loop_overhead = double(cur_loop_cnt) * cur_size * per_iteration_empty_loop_overhead_s;
        double fastest_nov = fastest - loop_overhead;
        uint64_t bytes_touched = 2 * cur_loop_cnt * cur_bytes;
        uint64_t lines_touched = bytes_touched / 64;
        double bandwidth_gbps = bytes_touched / fastest / (1024 * 1024 * 1024);
        double latency_ns = fastest / lines_touched * 1'000'000'000;
        double bandwidth_gbps_nov = bytes_touched / fastest_nov / (1024 * 1024 * 1024);
        double latency_ns_nov = fastest_nov / lines_touched * 1'000'000'000;
        ::printf(" %7s : %0.3f s, %6.3f GiB/s, %6.3f ns    (%0.3f s, %7.3f GiB/s, %6.3f ns)\n"
            , BytesStr(2 * cur_bytes)
            , fastest, bandwidth_gbps, latency_ns
            , fastest_nov, bandwidth_gbps_nov, latency_ns_nov
        );
        if (latency_ns_nov < min_ns) min_ns = latency_ns_nov;
        if (latency_ns_nov > max_ns) max_ns = latency_ns_nov;
    }
    ::printf ("\nSlowest to fastest latency ratio: %0.1f\n", max_ns / min_ns);

    ::printf("(%zu)\n", total);


    delete[] idx;
    delete[] mem;
    return 0;
}
