constexpr char const * AppName = "Sandbox";
constexpr size_t AntCount = 100'000;
#include "ants-common.hpp"

static void
Init (int /*width*/, int /*height*/) {
}

static void
Deinit () {
}

static void
Update (unsigned /*frame_number*/) {
}

static void
Render (unsigned frame_number, Canvas * canvas) {
    Texture_ClearToBlack(canvas);
        
    Color * p = canvas->row(frame_number / 10 % canvas->height);
    for (int i = 0; i < 100; ++i)
        *p++ = {0, 255, 255};
}
